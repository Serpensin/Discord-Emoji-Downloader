# Discord-Emoji-Downloader

With this Tool, you can download every Emoji from every DiscordServer you are currently in.
